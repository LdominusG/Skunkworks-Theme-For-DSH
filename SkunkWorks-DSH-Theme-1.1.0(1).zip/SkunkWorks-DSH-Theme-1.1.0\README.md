# Skunk Works · DeepSeek Harness 皮肤

夜库黑 `#05070A` + 琥珀 `#FFB000` + 钢蓝的 DSH 主题：三幕开屏、2.6 秒短卡、
会话区 44px 细钢灰网格、暗色机徽桌宠。走 DSH 自己的 token 层，不改应用二进制，
Light / Dark / System 切换照常可用。

- 主题包版本：`1.1.0`
- 构建：2026-10-18
- 实测：DeepSeek Harness `0.2.1-rc.2`（Windows）

## 1.1.0 修了什么

- 拖拽桌宠时不再触发浏览器原生的图片拖影（原图 370×400；`draggable=false` +
  `pointer-events:none` + `dragstart` 拦截）。
- badge/face 强制 78px 并裁切，图片再大也不会撑破圆形机徽。
- 气泡和 × 在贴边时自动翻转/收进视口；拖出窗口后自动收回。

1.0.0 的包可以作废；在旧版上直接装 1.1.0 覆盖即可。

## 包内文件

| 文件 | 用途 |
|---|---|
| `skunkworks-dsh-theme-1.1.0.tgz` | 主题本体，安装用 |
| `install-windows.cmd` | Windows 一键安装（自动找应用自带的 dsh CLI） |
| `SHA256.txt` | 主题包校验值 |
| `preview/` | 开屏与桌宠截图 |
| `README.md` | 本文件 |

## 安装（Windows，推荐）

0. 如果之前从没启动过 DeepSeek Harness，先启动一次再完全退出，让它初始化
   `desktop` profile。
1. **完全退出** DeepSeek Harness：托盘图标 → 退出。只关窗口不算，进程还在。
2. 解压本包，双击 `install-windows.cmd`。
   - 脚本会先检查应用是否还在运行，然后找应用自带的 `dsh` CLI，执行
     `plugin --profile desktop add`。
   - 看到 `[OK] Installed.` 即成功。
   - 如果 Windows 提示“已阻止”，右键脚本 → 属性 → 勾选“解除锁定”再运行。
3. 重新启动 DeepSeek Harness。

> 安装后建议保留这个包（至少保留 tgz）。profile 里记的是 tgz 的 `file:` 路径；
> 删掉后主题仍能运行，但以后重装 / 修复依赖时可能找不到源包。

> 如果脚本提示找不到 CLI，按下面的“手动安装”走一遍即可；安装逻辑是一样的。

### 手动安装（Windows / macOS / Linux）

先完全退出应用，然后进入本包所在目录：

**Windows（cmd）**
```bat
cd /d "<解压目录>"
"<DeepSeek Harness 安装目录>\resources\runtime\cli\bin\dsh.cmd" plugin --profile desktop add "skunkworks-dsh-theme-1.1.0.tgz"
```

**macOS**（应用路径以实际安装为准）
```bash
cd "<解压目录>"
"/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh" plugin --profile desktop add "skunkworks-dsh-theme-1.1.0.tgz"
```

**Linux**
```bash
cd "<解压目录>"
"<DeepSeek Harness 安装目录>/resources/runtime/cli/bin/dsh" plugin --profile desktop add "skunkworks-dsh-theme-1.1.0.tgz"
```

如果 `dsh` 已经在 PATH 里，直接：
```bash
dsh plugin --profile desktop add "skunkworks-dsh-theme-1.1.0.tgz"
```

安装后重启应用。用 `web` 或其它 profile 时，把命令里的 `desktop` 换成你的
profile 名。

## 卸载

用安装时同一个 `dsh`（Windows 上就是
`<DeepSeek Harness 安装目录>\resources\runtime\cli\bin\dsh.cmd`；PATH 里有 `dsh`
就直接用）：

```bash
dsh plugin --profile desktop remove @skunkworks/dsh-theme
```

重启后原生外观完全回来（token 层、chrome 样式、`data-skunkworks` 属性都会移除）。
也可以在应用的“插件”页里移除这个 bundle。

## 会看到什么

- **主题**：199 个 `{ light, dark }` token；应用自带的 Light / Dark / System 切换
  仍然有效，皮肤会跟着重组。
- **开屏**：绿字终端自检 → 暗场金属字标 → 臭鼬机徽；完整版约 7 秒，任意键 /
  点击可跳过；系统开启“减少动态效果”时退化为 1.2 秒静态卡。
- **短卡**：冷启动距上次完整版满 12 小时才放完整版，其余启动放 2.6 秒短卡；
  从托盘恢复也走短卡；想再看完整版，双击右下角桌宠。第一次安装后启动会走完整版
  （本机还没有完整版记录）。
- **会话区**：44px 细钢灰网格 + 暗角 + 尘点，固定在 `[data-conversation-scroll]`
  上，不随消息滚走。
- **桌宠**：右下角圆形机徽；单击出短句，双击重放完整开屏，可拖动；右上角 ×
  只隐藏本次启动，下次启动回来。
- **页脚**：极暗刻字 `BE QUICK · BE QUIET · BE ON TIME · KEEP IT SIMPLE, STUPID`。

## 预览

![Skunk Works 开屏](preview/03-skunk-works.png)

其余截图：`preview/01-terminal.png`（终端自检）、`preview/02-wordmark.png`
（金属字标）、`preview/04-motto.png`（字标细节）、`preview/05-desk-pet.png`
（桌宠）。

## 校验（可选）

Windows：
```bat
certutil -hashfile skunkworks-dsh-theme-1.1.0.tgz SHA256
```
与 `SHA256.txt` 里的值一致即可。

## 兼容性与说明

- 在 DeepSeek Harness `0.2.1-rc.2` 上安装并 `--dump-config` 验证过；主题依赖
  DSH 的稳定 `data-*` 属性与 `--dsw-*` token。DSH 大版本升级后如果颜色或布局
  对不上，需要重新对一遍 token。
- 个人玩梗主题，与 Lockheed Martin、DeepSeek 均无隶属关系；Lockheed Martin
  字标与臭鼬素材仅作个人分享，请勿商用。
- 安装包是 DSH 插件（客户端 + 一个宿主注入半层），只读应用、不改二进制；
  卸载并重启即还原。
- 开屏只在首个窗口播放；第二个窗口会通过 BroadcastChannel 保持安静。
