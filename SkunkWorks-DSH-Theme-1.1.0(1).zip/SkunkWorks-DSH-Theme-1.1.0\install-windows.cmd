@echo off
setlocal EnableExtensions
title Skunk Works DSH Theme - installer
cd /d "%~dp0"

set "PKG=%~dp0skunkworks-dsh-theme-1.1.0.tgz"
if not exist "%PKG%" (
  echo [X] Missing skunkworks-dsh-theme-1.1.0.tgz next to this script.
  goto :fail
)

if /i "%SKW_DRY%"=="1" goto :skip_running_check
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-Process -Name 'DeepSeek Harness' -ErrorAction SilentlyContinue) { exit 1 } else { exit 0 }"
if errorlevel 1 (
  echo [!] DeepSeek Harness is running.
  echo     Quit it completely first ^(tray icon - Quit^), then run this again.
  goto :fail
)
:skip_running_check

set "DSH="
call :find_app
if not defined DSH for /f "delims=" %%I in ('where dsh 2^>nul') do set "DSH=%%I"
if not defined DSH (
  echo [X] Could not find the dsh CLI bundled with DeepSeek Harness.
  echo     Use the manual command in README.md instead.
  goto :fail
)

echo Using: "%DSH%"
if /i "%SKW_DRY%"=="1" (
  echo [dry-run] "%DSH%" plugin --profile desktop add "%PKG%"
  goto :done
)

echo Installing into profile "desktop"...
call "%DSH%" plugin --profile desktop add "%PKG%"
if errorlevel 1 (
  echo [X] Install failed. Read the message above.
  goto :fail
)

echo.
echo [OK] Installed.
echo      1. Start DeepSeek Harness.
echo      2. First launch: full splash. Later launches: 2.6s short card.
echo      Uninstall: "%DSH%" plugin --profile desktop remove @skunkworks/dsh-theme
goto :done

:find_app
for %%P in (
  "%LOCALAPPDATA%\Programs\DeepSeek Harness\DeepSeek Harness.exe"
  "%ProgramFiles%\DeepSeek Harness\DeepSeek Harness.exe"
  "%ProgramFiles(x86)%\DeepSeek Harness\DeepSeek Harness.exe"
  "%LOCALAPPDATA%\DeepSeek Harness\DeepSeek Harness.exe"
  "D:\DSH\DeepSeek Harness.exe"
) do (
  if exist "%%~P" call :try_app "%%~P"
)
goto :eof

:try_app
if defined DSH goto :eof
set "APPDIR=%~dp1"
if exist "%APPDIR%resources\runtime\cli\bin\dsh.cmd" (
  set "DSH=%APPDIR%resources\runtime\cli\bin\dsh.cmd"
)
goto :eof

:fail
echo.
if /i not "%SKW_DRY%"=="1" pause
exit /b 1

:done
echo.
if /i not "%SKW_DRY%"=="1" pause
exit /b 0
